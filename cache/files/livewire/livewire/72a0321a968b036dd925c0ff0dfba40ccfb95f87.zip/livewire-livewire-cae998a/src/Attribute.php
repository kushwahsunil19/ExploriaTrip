<?php

namespace Livewire;

use Livewire\Features\SupportAttributes\Attribute as BaseAttribute;

abstract class Attribute extends BaseAttribute
{
    //
}
