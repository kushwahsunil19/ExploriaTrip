<?php

namespace Laravel\Fortify\Contracts;

use Illuminate\Contracts\Support\Responsable;

interface TwoFactorDisabledResponse extends Responsable
{
    //
}
