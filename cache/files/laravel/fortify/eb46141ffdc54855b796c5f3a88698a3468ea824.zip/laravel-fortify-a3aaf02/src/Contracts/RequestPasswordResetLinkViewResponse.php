<?php

namespace Laravel\Fortify\Contracts;

use Illuminate\Contracts\Support\Responsable;

interface RequestPasswordResetLinkViewResponse extends Responsable
{
    //
}
